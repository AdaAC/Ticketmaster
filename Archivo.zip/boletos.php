<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<?php
     echo "<link rel='icon' href="2_.ico" type='imagen/icon'>";
    
   // $Artista=(isset($_POST["Artista"])&& $_POST["Artista"] !="")? $_POST['Artista']:"Falta Variable";
    // $boletos=(isset($_POST["Boletos"])&& $_POST["Boletos"] !="")? $_POST['Boletos']:"Falta Variable";
   //  $recinto=(isset($_POST["Lugar"])&& $_POST["Lugar"] !="")? $_POST['recinto']:"Falta Variable";
   //  $correo=(isset($_POST["correo"])&& $_POST["correo"] !="")? $_POST['correo']:"Falta Variable";
    // $nombre=(isset($_POST["nombre"])&& $_POST["nombre"] !="")? $_POST['nombre']:"Falta Variable";
   //  $apellido=(isset($_POST["apellido"])&& $_POST["apellido"] !="")? $_POST['apellido']:"Falta Variable";
   //  $asientos=(isset($_POST["radio"])&& $_POST["radio"] !="")? $_POST['radio']:"Falta Variable";
    // $fecha=(isset($_POST["fechayhora"])&& $_POST["fechayhora"] !="")? $_POST['fechayhora']:"Falta Variable";


     for($i=1;$i<=$Boletos;$i++){

        if($Artista=="ValentinElizalde")
        {
            
            echo "<center><table border='2' style; cellpading='20 px'>";
            echo "<thead>
                <tr> <center><h1> ¡Felicidades! </h1> </center> </tr>
            </thead>
                <tbody>
                    <td>
                        <center><h1> $Artista </h1> </center>
                        <center><img src='val.jpeg' width='300' height='200'></center>";

                
                echo "</td>
                <td>
                    <center><h2>$Lugar</h2></center>
                    <center><h3>$Zona</h3></center>";
                    switch ($Zona)
                    {
                        
                        case 'VIP':
                            echo "<img src='mapa.jpeg' alt='VIP' width ='200' height= '150'>";
                            break;
                        case 'Gradas';
                            echo "<img src='mapa.jpeg' alt='Gradas A' width='200' height='150'>";
                            break;
                        case 'General A';
                            echo "<img src='mapa.jpeg' alt='General A' width='200' height='150'>";
                            break;
                        case 'General B';
                            echo "<img src='mapa.jpeg' alt='General B' width='200' height='150'>";
                            break;
                    }
                    switch ($Lugar)
                {
                    case 'Estadio Azteca':
                        echo "<img src='EA.jpeg' alt='estadio' width ='200' height= '150'>";
                        break;
                    case 'Palacio de los Deportes':
                        echo "<img src='palacio.jpeg' alt='palacio' width ='200' height= '150'>";
                        break;
                    case 'Foro sol':
                        echo "<img src='foro.jpeg' alt='sol' width ='200' height= '150'>";
                        break;
                    case 'Auditorio Nacional':
                        echo "<img src='au.jpeg' alt='Auditorio' width ='200' height= '150'>";
                        break;
                }       
                echo "<span><h5>$nombre  $apellido</h5></span>
                     <h5>$correo</h5>
                     <h5>$extras</h5>";
                echo "</td>";
                echo "</tr>";
     echo "</tbody>";
    echo "</table>";
        }
           
            if($Artista=="ChalinoSanchez")
        {
            
            echo "<center><table border='2' style; cellpading='20 px'>";
            echo "<thead>
                <tr> <center><h1> ¡Felicidades! </h1> </center> </tr>
            </thead>
                <tbody>
                    <td>
                        <center><h1> $Artista </h1> </center>
                        <center><img src='chalino.jpeg' width='300' height='200'></center>";
                        
                
                echo "</td>
                <td>
                    <center><h2>$Lugar</h2></center>
                    <center><h3>$Zona</h3></center>";
                    switch ($Zona)
                    {
                        
                        case 'VIP':
                            echo "<img src='mapa.jpeg' alt='VIP' width ='200' height= '150'>";
                            break;
                       
                        case 'Gradas';
                            echo "<img src='mapa.jpeg' alt='Gradas A' width='200' height='150'>";
                            break;
                        case 'General A';
                            echo "<img src='mapa.jpeg' alt='General A' width='200' height='150'>";
                            break;
                        case 'General B';
                            echo "<img src='mapa.jpeg' alt='General B' width='200' height='150'>";
                            break;
                    }
                    switch ($Lugar)
                {
                    case 'Estadio Azteca':
                        echo "<img src= 'EA.jpeg' alt='estadio' width ='200' height= '150'>";
                        break;
                    case 'Palacio de los Deportes':
                        echo "<img src='palacio.jpeg' alt='palacio' width ='200' height= '150'>";
                        break;
                    case 'Foro sol':
                        echo "<img src='foro.jpeg' alt='sol' width ='200' height= '150'>";
                        break;
                    case 'Auditorio Nacional':
                        echo "<img src='au.jpeg' alt='auditorio' width ='200' height= '150'>";
                        break;
                }       
                echo "<span><h5>$nombre  $apellido</h5></span>
                     <h5>$correo</h5>
                     <h5>$extras</h5>";
                echo "</td>";
                echo "</tr>";
     echo "</tbody>";
    echo "</table>";
        }
        if($Artista=="JenniRivera")
        {
            
            echo "<center><table border='2' style; cellpading='20 px'>";
            echo "<thead>
                <tr> <center><h1> ¡Felicidades! </h1> </center> </tr>
            </thead>
                <tbody>
                    <td>
                        <center><h1> $Artista </h1> </center>
                        <center><img src='jenni.jpeg' width='300' height='200'></center>";
                     
                
                echo "</td>
                <td>
                    <center><h2>$Lugar</h2></center>
                    <center><h3>$Zona</h3></center>";
                    switch ($Zona)
                    {
                       
                        case 'VIP':
                            echo "<img src='mapa.jpeg' alt='VIP' width ='200' height= '150'>";
                            break;
                       
                        case 'Gradas ';
                            echo "<img src='mapa.jpeg' alt='Gradas A' width='200' height='150'>";
                            break;
                        case 'General A';
                            echo "<img src='mapa.jpeg' alt='General A' width='200' height='150'>";
                            break;
                        case 'General B';
                            echo "<img src='mapa.jpeg' alt='General B' width='200' height='150'>";
                            break;
                    }
                    switch ($Lugar)
                {
                    case 'Estadio Azteca':
                        echo "<img src='EA.jpeg' alt='estadio' width ='200' height= '150'>";
                        break;
                    case 'Palacio de los Deportes':
                        echo "<img src='palacio.jpeg' alt='palacio' width ='200' height= '150'>";
                        break;
                    case 'Foro sol':
                        echo "<img src='foro.jpeg' alt='sol' width ='200' height= '150'>";
                        break;
                    case 'Auditorio Nacional':
                        echo "<img src='au.jpeg' alt='auditorio' width ='200' height= '150'>";
                        break;
                }       
                echo "<span><h5>$nombre  $apellido</h5></span>
                     <h5>$correo</h5>
                     <h5>$extras</h5>";
                echo "</td>";
                echo "</tr>";
     echo "</tbody>";
    echo "</table>";
        }
        if($Artista=="SelenaQuintanilla")
        {
            
            echo "<center><table border='2' style; cellpading='20 px'>";
            echo "<thead>
                <tr> <center><h1> ¡Felicidades! </h1> </center> </tr>
            </thead>
                <tbody>
                    <td>
                        <center><h1> $Artista </h1> </center>
                        <center><img src='selena.jpeg' width='300' height='200'></center>";
                       
                
                echo "</td>
                <td>
                    <center><h2>$Lugar</h2></center>
                    <center><h3>$Zona</h3></center>";
                    switch ($Zona)
                    {
                       
                        case 'VIP':
                            echo "<img src='mapa.jpeg' alt='VIP' width ='200' height= '150'>";
                            break;
                       
                        case 'Gradas ';
                            echo "<img src='mapa.jpeg' alt='Gradas A' width='200' height='150'>";
                            break;
                        case 'General A';
                            echo "<img src='mapa.jpeg' alt='General A' width='200' height='150'>";
                            break;
                        case 'General B';
                            echo "<img src='mapa.jpeg' alt='General B' width='200' height='150'>";
                            break;
                    }
                    switch ($Lugar)
                {
                    case 'Estadio Azteca':
                        echo "<img src='EA.jpeg' alt='estadio' width ='200' height= '150'>";
                        break;
                    case 'Palacio de los Deportes':
                        echo "<img src='palacio.jpeg' alt='palacio' width ='200' height= '150'>";
                        break;
                    case 'Foro sol':
                        echo "<img src='foro.jpeg' alt='sol' width ='200' height= '150'>";
                        break;
                    case 'Auditorio Nacional':
                        echo "<img src='au.jpeg' alt='Auditorio' width ='200' height= '150'>";
                        break;
                }       
                echo "<span><h5>$nombre  $apellido</h5></span>
                     <h5>$correo</h5>
                     <h5>$extras</h5>";
                echo "</td>";
                echo "</tr>";
     echo "</tbody>";
    echo "</table>";
        }
        if($Artista=="JoanSebastian")
        {
            
            echo "<center><table border='2' style; cellpading='20 px'>";
            echo "<thead>
                <tr> <center><h1> ¡Felicidades! </h1> </center> </tr>
            </thead>
                <tbody>
                    <td>
                        <center><h1> $Artista </h1> </center>
                        <center><img src='joan.jpeg' width='300' height='200'></center>";
                   
                
                echo "</td>
                <td>
                    <center><h2>$Lugar</h2></center>
                    <center><h3>$Zona</h3></center>";
                    switch ($Zona)
                    {
                        
                        case 'VIP':
                            echo "<img src='mapa.jpeg' alt='VIP' width ='200' height= '150'>";
                            break;
                    
                        case 'Gradas';
                            echo "<img src='mapa.jpeg' alt='Gradas A' width='200' height='150'>";
                            break;
                        case 'General A';
                            echo "<img src='mapa.jpeg' alt='General A' width='200' height='150'>";
                            break;
                        case 'General B';
                            echo "<img src='mapa.jpeg' alt='General B' width='200' height='150'>";
                            break;
                    }
                    switch ($Lugar)
                {
                    case 'Estadio Azteca':
                        echo "<img src='EA.jpeg' alt='estadio' width ='200' height= '150'>";
                        break;
                    case 'Palacio de los Deportes':
                        echo "<img src='palacio.jpeg' alt='palacio' width ='200' height= '150'>";
                        break;
                    case 'Foro sol':
                        echo "<img src='foro.jpeg' alt='sol' width ='200' height= '150'>";
                        break;
                    case 'Auditorio Nacional':
                        echo "<img src='au.jpeg' alt='auditorio' width ='200' height= '150'>";
                        break;
                }       
                echo "<span><h5>$nombre  $apellido</h5></span>
                     <h5>$correo</h5>
                     <h5>$extras</h5>";
                echo "</td>";
                echo "</tr>";
     echo "</tbody>";
    echo "</table>";
        }

        if($Artista=="JoseAlfredo")
        {
            
            echo "<center><table border='2' style; cellpading='20 px'>";
            echo "<thead>
                <tr> <center><h1> ¡Felicidades! </h1> </center> </tr>
            </thead>
                <tbody>
                    <td>
                        <center><h1> $Artista </h1> </center>
                        <center><img src='josea.jpeg' width='300' height='200'></center>";
                       
                
                echo "</td>
                <td>
                    <center><h2>$Lugar</h2></center>
                    <center><h3>$Zona</h3></center>";
                    switch ($Zona)
                    {
                        
                        case 'VIP':
                            echo "<img src='mapa.jpeg' alt='VIP' width ='200' height= '150'>";
                            break;
                    
                        case 'Gradas';
                            echo "<img src='mapa.jpeg' alt='Gradas A' width='200' height='150'>";
                            break;
                        case 'General A';
                            echo "<img src='mapa.jpeg' alt='General A' width='200' height='150'>";
                            break;
                        case 'General B';
                            echo "<img src='mapa.jpeg' alt='General B' width='200' height='150'>";
                            break;
                    }
                    switch ($Lugar)
                {
                    case 'Estadio Azteca':
                        echo "<img src='EA.jpeg' alt='estadio' width ='200' height= '150'>";
                        break;
                    case 'Palacio de los Deportes':
                        echo "<img src='palacio.jpeg' alt='palacio' width ='200' height= '150'>";
                        break;
                    case 'Foro sol':
                        echo "<img src='foro.jpeg' alt='sol' width ='200' height= '150'>";
                        break;
                    case 'Auditorio Nacional':
                        echo "<img src='au.jpeg' alt='auditorio' width ='200' height= '150'>";
                        break;
                }       
                echo "<span><h5>$nombre  $apellido</h5></span>
                     <h5>$correo</h5>
                     <h5>$extras</h5>";
                echo "</td>";
                echo "</tr>";
     echo "</tbody>";
    echo "</table>";
        }

        if($Artista=="JoseJose")
        {
            
            echo "<center><table border='2' style; cellpading='20 px'>";
            echo "<thead>
                <tr> <center><h1> ¡Felicidades! </h1> </center> </tr>
            </thead>
                <tbody>
                    <td>
                        <center><h1> $Artista </h1> </center>
                        <center><img src='jose.jpeg' width='300' height='200'></center>";
                        
                
                echo "</td>
                <td>
                    <center><h2>$Lugar</h2></center>
                    <center><h3>$Zona</h3></center>";
                    switch ($Zona)
                    {
                        
                        case 'VIP':
                            echo "<img src='mapa.jpeg' alt='VIP' width ='200' height= '150'>";
                            break;
                    
                        case 'Gradas';
                            echo "<img src='mapa.jpeg' alt='Gradas A' width='200' height='150'>";
                            break;
                        case 'General A';
                            echo "<img src='mapa.jpeg' alt='General A' width='200' height='150'>";
                            break;
                        case 'General B';
                            echo "<img src='mapa.jpeg' alt='General B' width='200' height='150'>";
                            break;
                    }
                    switch ($Lugar)
                {
                    case 'Estadio Azteca':
                        echo "<img src='EA.jpeg' alt='estadio' width ='200' height= '150'>";
                        break;
                    case 'Palacio de los Deportes':
                        echo "<img src='palacio.jpeg' alt='palacio' width ='200' height= '150'>";
                        break;
                    case 'Foro sol':
                        echo "<img src='foro.jpeg' alt='sol' width ='200' height= '150'>";
                        break;
                    case 'Auditorio Nacional':
                        echo "<img src='au.jpeg' alt='auditorio' width ='200' height= '150'>";
                        break;
                }       
                echo "<span><h5>$nombre  $apellido</h5></span>
                     <h5>$correo</h5>
                     <h5>$extras</h5>";
                echo "</td>";
                echo "</tr>";
     echo "</tbody>";
    echo "</table>";
        }

    }

?>

</body>
</html>
